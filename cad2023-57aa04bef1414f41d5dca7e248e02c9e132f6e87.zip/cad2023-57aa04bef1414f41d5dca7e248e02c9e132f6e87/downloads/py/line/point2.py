def point():
    return "可以傳回 point"