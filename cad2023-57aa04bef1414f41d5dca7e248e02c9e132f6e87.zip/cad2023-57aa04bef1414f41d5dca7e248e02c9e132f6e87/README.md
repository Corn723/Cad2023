# cmsite
cmsimde template uses mdecycu/cmsimde as submodule

On Replit:

for cmsite: git submodule update --init --recursive 

for cmsimde_site: cmsimde is as directory not submodule

for cmsimde: pip install flask flask_cors bs4 lxml pelican markdown gevent
